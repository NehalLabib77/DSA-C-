#include<bits/stdc++.h>
using namespace std;

int main ()
{
    float n,m,a;
    cin>>n>>m>>a;

    int d=m*n,p=a*a;
    if(d%p==0) cout<<d/(a*a)<<endl;
    else
    {
        float x=ceil(n/a)+ceil(m/a);
        cout<<x<<endl;
    }
}
