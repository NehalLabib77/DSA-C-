#include<bits/stdc++.h>
using namespace std;

int main ()
{
    int t;
    cin>>t;

    while(t--)
    {
        int n;
        cin>>n;

        vector<int> v(n); // Create a vector of size n
        for (int i = 0; i < n; i++) {
            cin >> v[i]; // Input elements into the vector
        }
        int d=5;
        for(int i=0; i<v.size(); i++)
        {
            if(d==v[i]) v.erase(v.begin()+i);
        }
        int j=0;
        for(int i=0; i<v.size(); i++)
        {
            cout<<v[i]<<" ";
            j++;
        }
        cout<<endl;
        cout<<"j :"<<j<<endl;
    }
}
