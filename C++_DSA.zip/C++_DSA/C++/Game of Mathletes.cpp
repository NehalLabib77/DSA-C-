#include<bits/stdc++.h>
using namespace std;

int main ()
{
    int t;
    cin>>t;

    while(t--)
    {
        long long n,m;
        cin>>n>>m;

        vector<long long>v(n);
        for (long long i=0; i<n; i++) cin>>v[i];

        list<long long>li;
        list<long long>::iterator it;
        it=li.begin();
        long long k=0,d=-1;
        for(long long i=0; i<v.size(); i++)
        {
            for(long long  j=i+1; j<v.size(); j++)
            {
                    if(v[i]+v[j]==m)
                    {
                       advance(it,j);
                       li.erase(it);
                        k++;
                        break;
                    }
            }
        }
        for(int i=0; i<v.size(); i++) cout<<v[i]<<" ";
        cout<<endl;
        cout<<k<<endl;

    }
}
