
#include<bits/stdc++.h>
using namespace std;

int main ()
{
    int t;
    cin>>t;

    while(t--)
    {
       long long a,b,c;
       cin>>a>>b>>c;

       long long d=c/2;
       if(c%2==0)
       {
           cout<<a*d-b*d<<endl;
       }
       else
       {
           d=d+1;
           cout<<a*d-b*(c-d)<<endl;
       }

    }
}
