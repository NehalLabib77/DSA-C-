#include <iostream>
using namespace std;

const int MAX = 100;

void warshall(int reach[][MAX], int n)
{

    for (int k = 0; k < n; k++)
    {
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                reach[i][j] = reach[i][j] || (reach[i][k] && reach[k][j]);
            }
        }
    }
}

void printMatrix(int matrix[][MAX], int n)
{
    cout << "\nTransitive Closure:\n";
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cout << matrix[i][j] << " ";
        }
        cout << endl;
    }
}

int main()
{
    int n;
    int graph[MAX][MAX];

    cout << "Enter the number of vertices: ";
    cin >> n;

    cout << "Enter the adjacency matrix (" << n << "x" << n << "):\n";
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cin >> graph[i][j];
        }
    }

    warshall(graph, n);
    printMatrix(graph, n);

    return 0;
}
