#include<bits/stdc++.h>
using namespace std;

int main ()
{
    int t;
    cin>>t;

    while(t--)
    {
        int n;
        cin>>n;

        int x=n;
        int i=0,k=0;
            while(x!=1)
            {
                if(x%6==0)
                {
                    x=x/6;
                    i++;
                }
                else
                {
                    x=x*2;
                    i++;
                    if(x%6==0)
                    {
                        x=x/6;
                        i++;
                    }
                    else{
                        k=1;
                         break;
                    }
                }
            }
            if(k==1) cout<<"-1"<<endl;
            else cout<<i<<endl;

    }
}
