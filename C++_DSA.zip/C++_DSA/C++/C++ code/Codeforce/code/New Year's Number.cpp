#include<bits/stdc++.h>
using namespace std;

int main ()
{
    int t;
    cin>>t;

    while(t--)
    {
        int n;
        cin>>n;

        int div,rem;
        div=(n/1000)/2;
        rem=n%10;
        int x=2021*rem+((div-rem)*2020);

        if(div==0 || x!=n) cout<<"NO"<<endl;
        else cout<<"YES"<<endl;
        //cout<<div<<" "<<rem<<endl;

    }
}
