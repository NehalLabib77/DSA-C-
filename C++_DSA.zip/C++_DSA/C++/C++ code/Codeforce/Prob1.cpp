    #include<iostream>
    using namespace std;
    int main(){

    long long n;
    cin >> n;
    int a[n];


        for(int i=0; i<n; i++){
            cin >> a[i];
        }
        int min = a[0];
        int p=1;
        for(int i=1; i<n; i++){

        if(a[i] < min){
        min = a[i];
         p = i+1 ;
        }
        
    }
    
    cout << min << " " << p << endl;
    
}