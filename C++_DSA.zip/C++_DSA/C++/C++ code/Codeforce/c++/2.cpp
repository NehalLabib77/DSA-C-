#include<iostream>
using namespace std;
int c=50;
int main(){

    int c;
    cout<<::c;

}
