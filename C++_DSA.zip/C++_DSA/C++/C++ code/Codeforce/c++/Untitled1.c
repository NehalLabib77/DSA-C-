#include <stdio.h>

int main()
{
    int t;
    scanf("%d", &t);
    while (t--)
    {
        int n;
        scanf("%d", &n);

        int a[n];
        for (int i = 0; i < n; i++)
        {
            scanf("%d", &a[i]);
        }

        int count = 0;
        for (int i = 1; i < n - 1; i++)
        {
            int lmax = a[0];
            int rmin = a[n - 1];
            for (int j = 0; j < i; j++)
            {
                lmax = (lmax > a[j]) ? lmax : a[j];
            }

            for (int j = n - 1; j > i; j--)
            {
                rmin = (rmin < a[j]) ? rmin : a[j];
            }
            if (a[i] > lmax && a[i] < rmin)
            {
                count++;
            }
        }

        printf("%d\n", count);
    }

    return 0;
}
