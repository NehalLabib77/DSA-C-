#include<iostream>
using namespace std;
int main()
{
    int n;
    int c=0;
    cin>>n;
    int x,y,z;

        for(int i=1; i<=n; i++)
        {
            cin>> x >> y >> z;
            if(x+y+z >= 2){
                c++;
            }
        }

    cout<<c<<endl;

}
