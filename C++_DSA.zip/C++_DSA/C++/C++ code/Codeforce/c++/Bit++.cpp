#include<iostream>
#include<string>
using namespace std;
int main()
{
    int X=0,n;
    cin>>n;
    string s;

    for(int i=1; i<=n; i++){
        cin>>s;
        if(s[1] == '+'){
            X++;
        }
        else{
            X--;
        }
    }
    cout<<X<<endl;

}

