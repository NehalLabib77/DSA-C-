#include<stdio.h>
void max_arr(int x[])
{
   int i,max=x[0];
   for(i=0;i<5;i++){
        if(x[i]>max)
        max=x[i];
   }
   printf("%d\n",max);
}
int main()
{
    int arr[]={1,2,3,4,5};
    max_arr(arr);
}
