#include <stdio.h>

int main(void) {
	int t;
	scanf("%d",&t);

	while(t--){

	    char n1,n2;
	    scanf("%s",&n1);
	   n2= strrev(n1);

	    int d = strcmp(n1,n2);

	    if(d == 0){
	        printf("wins");
	    }
	    else
	    printf("loses");
	}

}
