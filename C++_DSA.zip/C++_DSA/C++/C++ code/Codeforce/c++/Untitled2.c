#include<stdio.h>
int main(){
	int t=0;
	scanf("%d",&t);
	while(t--){
	    char s1[5];
	    scanf("%s",&s1);

	     char s2[5];
	    scanf("%s",&s2);

	   int i=0,j=0;

	    while(s1[i] !=0 && s2[j] !=0){
	        i++;
	        j++;
	    }

	    int d = strcmp(s1[i],s2[j]);

	    if(d==0){
	        printf("G");
	    }
	    else
	        printf("B");
}}
