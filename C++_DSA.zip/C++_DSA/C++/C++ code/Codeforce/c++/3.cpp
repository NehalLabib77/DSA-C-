#include<iostream>
using namespace std;
int main()
{
    int x,y,sum;

    sum= (x=10,y=20,sum=x+y);

    cout<<sum;


}
