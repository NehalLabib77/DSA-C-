#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    int n1=10,n2=12;
    float n3=12.3;
    double n4=12.56748;
    char ch='a';
    cout<< "n1=" << n1<<endl << "n2="<< n2<<endl << "n3="<< n3<<endl << "n4="<< n4<<endl<<"ch="<<ch<<endl;
    getch();
}

