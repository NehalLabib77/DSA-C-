#include <stdio.h>

int main() {
    int a, n, x, c = 0;

    scanf("%d", &a);

    for (int i = 0; i < a; i++) { // Modified loop condition
        scanf("%d", &n);

        while (n--) {
            scanf("%d", &x);
          int  y = 0; // Reset y for each inner loop iteration
            if (x == y) {
                c++;
            }
        }
    }

    printf("%d\n", c);

    return 0;
}
