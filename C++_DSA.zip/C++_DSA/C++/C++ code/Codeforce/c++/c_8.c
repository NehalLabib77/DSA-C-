#include<iostream>
using namespace std;
int main()
{
    int n,i,j;
    cin>>n;
    char c1,c2 = {},{};
    for(i=0; i<n; i++){

        cin>>c1>>c2;

        int r = strcmp(c1,c2);

        if(r==0){
        cout<<"0";
    }
    else{
        if(result < 0){
            cout<"-1";
        }
        else{
            cout<<"1";
        }
    }

    }

}
