#include <stdio.h>

void decimalToBinary(int n) {
    // Array to store binary number
    int binary[32];
    int i = 0;

    if (n == 0) {
        printf("0");
        return;
    }

    while (n > 0) {
        binary[i] = n % 2; // Store remainder (0 or 1)
        n = n / 2; // Divide number by 2
        i++;
    }

    // Print binary number in reverse order
    printf("Binary: ");
    for (int j = i - 1; j >= 0; j--) {
        printf("%d", binary[j]);
    }
    printf("\n");
}

int main() {
    int decimalNumber;

    // Input from user
    printf("Enter a decimal number: ");
    scanf("%d", &decimalNumber);

    // Call the function to convert decimal to binary
    decimalToBinary(decimalNumber);

    return 0;
}
