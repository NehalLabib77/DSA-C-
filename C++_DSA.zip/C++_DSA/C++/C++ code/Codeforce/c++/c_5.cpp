#include<iostream>
using namespace std;
int main(){

    int m,n,z =0;

    cin>>m>>n;

    z = m*n / 2;

    cout << z << endl;

}

