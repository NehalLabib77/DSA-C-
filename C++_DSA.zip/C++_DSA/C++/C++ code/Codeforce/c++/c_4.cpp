#include<iostream>
using namespace std;
int main(){

    int n,i,k,count = 0;
    cin>> n >> k;
    int a[500];

    for(i=0; i<n; i++){
       cin >> a[i];
    }

       for( i=0; i<n; i++){
       if(a[i] >= a[k-1] && a[i] > 0){
        count++;
       }
    }

    cout<< count <<endl;
}
