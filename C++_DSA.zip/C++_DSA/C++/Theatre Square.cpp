#include<bits/stdc++.h>
using namespace std;

int main ()
{
    float m,n,a;
    cin>>m>>n>>a;

    float d=ceil(m/a)+ceil(n/a);
    cout<<d<<endl;

}
