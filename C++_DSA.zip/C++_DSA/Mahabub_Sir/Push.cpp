#include <iostream>
#include <stack>

using namespace std;
int main()
{
    stack <int> s;
    int n, x;

    cout << "Enter the elements to push :" << endl;
    cin >> n;

    for (int i = 0; i < n; i++)
    {
        cout << "Enter the value to push :" << endl;
        cin >> x;
        s.push(x);
        cout << "Pushed " << x << "current top is :" << s.top() << endl;
    }
}