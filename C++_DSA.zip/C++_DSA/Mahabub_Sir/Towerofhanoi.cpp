#include <iostream>
#include <stack>
#include <vector>
using namespace std;

void hanoi(int n, char beg, char aux, char end)
{
    stack<pair<int, vector<char>>> s;
    s.push({n, {beg, aux, end}});

    while (!s.empty())
    {
        int n = s.top().first;
        char beg = s.top().second[0];
        char aux = s.top().second[1];
        char end = s.top().second[2];
        s.pop();
        if (n == 1)
        {
            cout << beg << " => " << end << endl;
        }
        else
        {
            s.push({n - 1, {aux, beg, end}});
            s.push({1, {beg, aux, end}});
            s.push({n - 1, {beg, end, aux}});
        }
    }
}
int main()
{
    hanoi(3, 'A', 'B', 'C');
    return 0;
}