#include <iostream>
using namespace std;

int fact(int n1)
{
    if (n1 == 0)
        return 1;
    else
        return n1 * fact(n1 - 1);
}

int fibonachi(int n2)
{
    if (n2 == 0 || n2 == 1)
        return n2;
    return fibonachi(n2 - 1) + fibonachi(n2 - 2);
}

int main()
{
    int n1 = 4;
    cout << "Factorial of " << n1 << " is: " << fact(n1) << endl;
    int n2 = 10;
    cout << "Fibonachi of " << n2 << " is: " << fibonachi(n2) << endl;
    return 0;
}
