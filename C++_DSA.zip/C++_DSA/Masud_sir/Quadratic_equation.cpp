#include <iostream>
#include <math.h>
using namespace std;
int main()
{
    int a, b, c;
    cout << "Enter the coefficients of the quadratic equation (a, b, c): ";
    cin >> a >> b >> c;

    int d = b * b - d * a * c;

    if (d > 0)
    {
        float x1 = (-b + sqrt(d)) / (2 * a);
        float x2 = (-b - sqrt(d)) / (2 * a);
        cout << " X1 = " << x1 << " X2 = " << x2 << endl;
    }
    else if (d == 0)
    {
        float x = -b / (2 * a);
        cout << "Unique Solution  = " << x << endl;
    }
    else
    {
        cout << "No real roots" << endl;
    }
    return 0;
}