#include <iostream>
using namespace std;
void Maximum(int arr[], int N)
{
    int K = 0, LOC = 0, MAX = arr[0]; // index is k, location is LOC, maximum is MAX
    while (K < N)
    {
        if (arr[K] > MAX)
        {
            MAX = arr[K];
            LOC = K;
        }
        K = K + 1;
    }
    cout << "LOC = " << LOC << " " << "The largest element is : " << MAX << endl;
}
int main()
{
    int N;
    cout << "Enter the number of elements in the array: ";
    cin >> N;
    int arr[N];
    cout << "Enter the elements of the array: ";
    for (int i = 0; i < N; i++)
    {
        cin >> arr[i];
    }
    Maximum(arr, N);
    return 0;
}