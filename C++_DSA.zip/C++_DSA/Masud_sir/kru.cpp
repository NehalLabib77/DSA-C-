#include <bits/stdc++.h>
using namespace std;

const int MAXN = 1000;
int parent[MAXN];

int find(int u)
{
    return parent[u] == u ? u : parent[u] = find(parent[u]);
}

void unite(int u, int v)
{
    parent[find(u)] = find(v);
}

int main()
{
    int n, e;
    cout << "Enter number of nodes and edges: ";
    cin >> n >> e;

    vector<tuple<int, int, int>> edges;

    cout << "Enter edges as: node1 node2 weight\n";
    for (int i = 0; i < e; i++)
    {
        int u, v, w;
        cin >> u >> v >> w;
        edges.push_back(make_tuple(w, u, v));
    }

    for (int i = 0; i <= n; i++)
        parent[i] = i;

    sort(edges.begin(), edges.end());

    int weight = 0;
    cout << "\nEdges in MST:\n";
    for (auto edge : edges)
    {
        int w = get<0>(edge);
        int u = get<1>(edge);
        int v = get<2>(edge);

        if (find(u) != find(v))
        {
            unite(u, v);
            cout << u << " - " << v << " : " << w << endl;
            weight += w;
        }
    }
    cout << "Total Weight: " << weight << endl;
    return 0;
}
