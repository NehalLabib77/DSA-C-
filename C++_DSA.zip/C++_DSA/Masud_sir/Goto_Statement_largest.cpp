#include <iostream>
using namespace std;
void Maximum(int arr[], int N)
{
    int k = 0, LOC = 0, MAX = arr[0]; // index is k, location is LOC, maximum is MAX
increament_counter:
    k = k + 1;
    if (k == N)
    {
        cout << "LOC = " << LOC << " " << "MAX = " << MAX << endl;
        return;
    }
    if (arr[k] > MAX)
    {
        LOC = k;
        MAX = arr[k];
    }
    goto increament_counter;
}
int main()
{
    int N;
    cout << "Enter the number of elements =";
    cin >> N;

    int arr[N];
    cout << "Enter the   elements in the array: ";

    for (int i = 0; i < N; i++)
    {
        cin >> arr[i];
    }
    Maximum(arr, N);
    return 0;
}