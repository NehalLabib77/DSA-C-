#include <stdio.h>
#include <time.h>

int linearSearch(int arr[], int n, int key)
{
    for (int i = 0; i < n; i++)
    {
        if (arr[i] == key)
            return i;
    }
    return -1;
}

int binarySearch(int arr[], int low, int high, int key)
{
    while (low <= high)
    {
        int mid = (low + high) / 2;
        if (arr[mid] == key)
            return mid;
        else if (arr[mid] < key)
            low = mid + 1;
        else
            high = mid - 1;
    }
    return -1;
}

int main()
{
    int n = 100000;
    int arr[n];
    for (int i = 0; i < n; i++)
    {
        arr[i] = i;
    }
    int key = n - 1;

    clock_t start, end;
    double cpu_time_used;

    // Linear Search
    start = clock();
    int linearIndex = linearSearch(arr, n, key);
    end = clock();
    cpu_time_used = ((double)(end - start)) / CLOCKS_PER_SEC;
    printf("Linear Search: Index = %d, Time = %f seconds\n", linearIndex, cpu_time_used);

    // Binary Search
    start = clock();
    int binaryIndex = binarySearch(arr, 0, n - 1, key);
    end = clock();
    cpu_time_used = ((double)(end - start)) / CLOCKS_PER_SEC;
    printf("Binary Search: Index = %d, Time = %f seconds\n", binaryIndex, cpu_time_used);

    return 0;
}
