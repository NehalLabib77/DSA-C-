#include <bits/stdc++.h>
using namespace std;

int main()
{
    int V;
    cin >> V;
    vector<vector<int>> graph(V, vector<int>(V));
    for (auto &row : graph)
        for (auto &w : row)
            cin >> w;

    vector<int> key(V, INT_MAX), parent(V, -1);
    vector<bool> visited(V, false);
    key[0] = 0;

    for (int i = 0; i < V; i++)
    {
        int u = -1, minKey = INT_MAX;
        for (int v = 0; v < V; v++)
            if (!visited[v] && key[v] < minKey)
            {
                minKey = key[v];
                u = v;
            }
        visited[u] = true;

        for (int v = 0; v < V; v++)
            if (graph[u][v] && !visited[v] && graph[u][v] < key[v])
            {
                key[v] = graph[u][v];
                parent[v] = u;
            }
    }

    cout << "Edge \tWeight\n";
    for (int i = 1; i < V; i++)
        cout << parent[i] << " - " << i << " \t" << graph[i][parent[i]] << "\n";

    return 0;
}
