#include <iostream>
using namespace std;

int **createMatrix(int row, int col)
{
    int **matrix = new int *[row];
    for (int i = 0; i < row; i++)
    {
        matrix[i] = new int[col];
    }
    return matrix;
}

void printMatrix(int **matrix, int row, int col)
{
    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            cout << matrix[i][j] << " ";
        }
        cout << endl;
    }
}

void deleteMatrix(int **matrix, int row)
{
    for (int i = 0; i < row; i++)
    {
        delete[] matrix[i];
    }
    delete[] matrix;
}

void multiplyMatrix(int a[][3], int b[][3], int **c, int M, int P, int N)
{
    for (int i = 0; i < M; i++)
    {
        for (int j = 0; j < N; j++)
        {
            c[i][j] = 0;
            for (int k = 0; k < P; k++)
            {
                c[i][j] += a[i][k] * b[k][j];
            }
        }
    }
}

int main()
{
    int a[][3] = {{1, -2, 3}, {0, 4, 5}};
    int b[][3] = {{3, 0, -6}, {2, -3, 1}, {2, 5, 3}};
    int **c = createMatrix(2, 3);
    multiplyMatrix(a, b, c, 2, 3, 3);
    printMatrix(c, 2, 3);
    deleteMatrix(c, 2);
    return 0;
}
