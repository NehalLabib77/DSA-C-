#include <bits/stdc++.h>
using namespace std;

int main()
{
    int V, E, src;
    cin >> V >> E;
    vector<vector<pair<int, int>>> g(V);
    for (int i = 0; i < E; i++)
    {
        int u, v, w;
        cin >> u >> v >> w;
        g[u].push_back({v, w});
        g[v].push_back({u, w});
    }
    cin >> src;

    vector<int> dist(V, INT_MAX);
    dist[src] = 0;
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
    pq.push({0, src});

    while (!pq.empty())
    {
        auto p = pq.top();
        pq.pop();
        int d = p.first;
        int u = p.second;

        if (d > dist[u])
            continue;

        for (auto &edge : g[u])
        {
            int v = edge.first;
            int w = edge.second;
            if (dist[u] + w < dist[v])
            {
                dist[v] = dist[u] + w;
                pq.push({dist[v], v});
            }
        }
    }

    for (int i = 0; i < V; i++)
        cout << "Distance from " << src << " to " << i << " is " << dist[i] << "\n";

    return 0;
}
