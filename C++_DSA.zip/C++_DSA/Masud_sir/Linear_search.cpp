#include <iostream>
using namespace std;
void Linear(int arr[], int N, int x)
{
    

    int k = 0, LOC = -1;
    while (LOC == -1 && k < N) 
    {

        if (arr[k] == x)
        {
            LOC = k;
        }
        k++;
    }
    if (LOC == -1)
    {
        cout << "The element is not found" << endl;
    }
    else
    {
        cout << "The element is found at location: " << LOC << endl;
        return;
    }
}

int main()
{
    int N;
    cout << "Enter the number of elements in the array: ";
    cin >> N;
    int x = 5;
    int arr[N];
    cout << "Enter the elements of the array: ";
    for (int i = 0; i < N; i++)
    {
        cin >> arr[i];
    }
    Linear(arr, N, x);
    return 0;
}