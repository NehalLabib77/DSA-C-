#include <bits/stdc++.h>
using namespace std;

int main()
{
    int V, E, src;
    cin >> V >> E;

    vector<tuple<int, int, int>> edges;
    for (int i = 0; i < E; ++i)
    {
        int u, v, w;
        cin >> u >> v >> w;
        edges.push_back(make_tuple(u, v, w));
    }

    cin >> src;
    vector<int> dist(V, INT_MAX);
    dist[src] = 0;

    for (int i = 1; i < V; ++i)
    {
        for (auto edge : edges)
        {
            int u = get<0>(edge);
            int v = get<1>(edge);
            int w = get<2>(edge);
            if (dist[u] != INT_MAX && dist[u] + w < dist[v])
                dist[v] = dist[u] + w;
        }
    }

    for (auto edge : edges)
    {
        int u = get<0>(edge);
        int v = get<1>(edge);
        int w = get<2>(edge);
        if (dist[u] != INT_MAX && dist[u] + w < dist[v])
        {
            cout << "Negative cycle found\n";
            return 0;
        }
    }

    for (int i = 0; i < V; ++i)
    {
        cout << "Distance from " << src << " to " << i << " = ";
        if (dist[i] == INT_MAX)
            cout << "INF\n";
        else
            cout << dist[i] << "\n";
    }

    return 0;
}
